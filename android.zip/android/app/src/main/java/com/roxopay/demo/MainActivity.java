package com.roxopay.demo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    // TROQUE pelo endereço HTTPS público do seu servidor RoxoPay, sem barra no final.
    private static final String SERVER_URL = "https://COLOQUE-AQUI-SEU-SERVIDOR";
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (SERVER_URL.contains("COLOQUE-AQUI")) {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setGravity(Gravity.CENTER);
            layout.setPadding(36,36,36,36);
            layout.setBackgroundColor(Color.rgb(246,242,251));
            TextView title = new TextView(this);
            title.setText("RoxoPay — falta configurar o servidor");
            title.setTextSize(22);
            title.setTextColor(Color.rgb(65,35,105));
            TextView body = new TextView(this);
            body.setPadding(0,24,0,0);
            body.setTextSize(16);
            body.setText("Publique primeiro a pasta server e substitua SERVER_URL em MainActivity.java pelo endereço HTTPS publicado. Depois gere o APK novamente.");
            body.setTextColor(Color.DKGRAY);
            layout.addView(title); layout.addView(body); setContentView(layout);
            return;
        }
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl(SERVER_URL);
        setContentView(webView);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
